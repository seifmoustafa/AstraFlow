# Testing

## General-purpose assertions

See the [AstraFlow Assertions guide](assertions.md) for the current method list, semantics, package boundary, and unreleased 2.4.0 status.

`AstraFlow.Assertions` is the in-development general-purpose assertion library for tests of any .NET application. Its current source provides fluent checks for values and comparison ranges, booleans, strings, sequences and dictionaries, GUIDs, enums, synchronous exceptions, and asynchronous operations without requiring a particular test runner. It is not published yet.

Use it to verify the result or observable effects of the application under test. It is not a runtime input-validation library and does not execute or mock the application for you. An assertion failure throws `AstraFlowAssertionException`, which ordinary test runners report as a failed test.

```powershell
dotnet add package AstraFlow.Assertions --version 2.4.0
```

Run this install command after the 2.4.0 package is published; it cannot install the current source candidate from NuGet yet.

```csharp
using AstraFlow.Assertions;

response.StatusCode.Should().Be(200);
response.Body.Should().Contain("created");
items.Should().HaveCount(2);
await ((Func<Task>)(() => service.SaveAsync())).Should().NotThrowAsync();
```

This package is separate from `AstraFlow.Testing`; a project can install either or both according to whether it needs only assertions, AstraFlow-specific fakes/harnesses, or both.

Failure messages avoid rendering arbitrary objects or string contents by default, which helps keep secrets out of CI output. This first phase is a foundation, not a claim of complete API compatibility with another assertion framework.

## AstraFlow-specific test helpers

`AstraFlow.Testing` is an optional test-helper package for projects that use AstraFlow mediator, mapper, projections, diagnostics, or secure ID flows.

The shipping assembly has no dependency on a test runner, external assertion library, or mocking framework. Helpers throw `AstraFlowAssertionException`, so they can be used with any test runner.

Install:

```powershell
dotnet add package AstraFlow.Testing --version 2.3.0
```

## Fake Mediator

Use `FakeMediator` when a unit under test depends on `ISender`, `IPublisher`, or `IMediator` and you want to record what was sent or published.

```csharp
var mediator = new FakeMediator()
    .RespondWith<CreateUser, Guid>(Guid.Parse("11111111-1111-1111-1111-111111111111"))
    .OnPublish<UserCreated>((notification, cancellationToken) => Task.CompletedTask);

var id = await mediator.Send(new CreateUser("admin"));
await mediator.Publish(new UserCreated("admin"));

mediator.Requests.SingleSent<CreateUser>();
mediator.Notifications.SinglePublished<UserCreated>();
```

If a request is sent without a configured fake response, the fake throws a clear `InvalidOperationException`. This prevents tests from silently passing when a collaborator was not configured.

## Separate Fakes

Use `FakeSender` when a unit only sends requests.

```csharp
var sender = new FakeSender()
    .RespondWith<CreateUser, Guid>(Guid.NewGuid());

await sender.Send(new CreateUser("admin"));
sender.Requests.ShouldHaveSent<CreateUser>();
```

Use `FakePublisher` when a unit only publishes notifications.

```csharp
var publisher = new FakePublisher();

await publisher.Publish(new UserCreated("admin"));
publisher.Notifications.ShouldHavePublished<UserCreated>();
```

## Handler Harness

Use `HandlerTestHarness<TRequest, TResponse>` to execute a handler directly without building a service provider.

```csharp
var harness = new HandlerTestHarness<CreateUser, Guid>(handler);

var id = await harness.Handle(new CreateUser("admin"));
```

## Pipeline Harness

Use `PipelineTestHarness<TRequest, TResponse>` to verify behavior order, short-circuiting, and exception flow.

```csharp
var harness = new PipelineTestHarness<CreateUser, Guid>(
    new IPipelineBehavior<CreateUser, Guid>[] { behavior },
    (request, cancellationToken) => Task.FromResult(Guid.NewGuid()));

var id = await harness.Execute(new CreateUser("admin"));
```

For full mediator integration behavior, keep at least one DI-backed test that exercises the real mediator. This is especially useful for stream cancellation/disposal, processor ordering, exception handled-state behavior, and notification failure policy checks.

## Notification Handler Harness

Use `NotificationHandlerTestHarness<TNotification>` to execute one notification handler directly.

```csharp
var harness = new NotificationHandlerTestHarness<UserCreated>(handler);

await harness.Handle(new UserCreated("admin"));
```

## Mapper Assertions

Use mapper assertions to keep mapping tests concise.

```csharp
var dto = mapper.ShouldMapTo<UserResponse>(user);
mapper.ShouldFailMappingTo<PrivateUserResponse>(user);
validator.ShouldValidateMappings();
```

Use mapping-rule assertions when testing explicit rule ownership.

```csharp
rule.ShouldDeclare<User, UserResponse>();
rule.ShouldOwnMapping<User, UserResponse>();
```

## Projection Assertions

Use projection assertions to verify registry lookup and validation findings.

```csharp
registry.ShouldResolveProjection<User, UserListItem>("list");

var report = validator.Validate(new MappingOptions());
report.ShouldHaveProjectionFinding("AFP101");
```

Use projection plan assertions when tests export deterministic plans through `IProjectionPlanProvider`.

```csharp
var plans = planProvider.GetProjectionPlans();
var plan = plans.ShouldHaveParameterizedProjectionPlan<User, UserListItem, UserProjectionParameters>("list");

plan.ShouldHaveProjectionParameter("TenantId", typeof(Guid).FullName!);
plan.ShouldHaveNonSensitiveProjectionParameter("TenantId");
plan.ShouldHaveSensitiveProjectionParameter("AccessToken");
plan.ShouldHaveProjectionMember("Name", "Constructed");
plan.ShouldHaveNoProjectionPlanFindings();
```

## Diagnostics Assertions

Use diagnostics assertions when a test creates an `AstraFlowDiagnosticReport`.

```csharp
var report = diagnostics.CreateReport();

report.ShouldHaveNoDiagnosticErrors();
report.ShouldHaveDiagnosticFinding("AFD000");
```

## Secure ID Tests

`TestSecureIdCodec` is deterministic and test-only. It is not encryption and must not be used in production.

```csharp
var codec = new TestSecureIdCodec();
var encoded = codec.ShouldRoundTripSecureId(Guid.NewGuid());
```

## Design Rules

- Testing helpers do not log request payloads or DTO payloads.
- Fakes record object references and types so tests can make their own assertions.
- No helper depends on a specific test framework.
- No helper replaces integration tests for DI registration, EF Core translation, or application startup.


