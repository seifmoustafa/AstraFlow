# Compatibility

This guide documents AstraFlow target framework support, compatibility goals, and the rules for future target expansion. The maintainer reports `2.3.0` as published; `2.4.0` is unreleased source work.

## Current Support

The source package projects currently target the frameworks below. This table describes checked-in source assets; it does not prove that a particular package version is available on NuGet. Verify exact publication status independently before using a version as a consumer baseline.

| Package | Current targets |
| --- | --- |
| `AstraFlow` | `netstandard2.0`, `net8.0`, `net9.0`, `net10.0` |
| `AstraFlow.Contracts` | `netstandard2.0`, `net8.0`, `net9.0`, `net10.0` |
| `AstraFlow.Mediator` | `netstandard2.0`, `net8.0`, `net9.0`, `net10.0` |
| `AstraFlow.Mapper` | `netstandard2.0`, `net8.0`, `net9.0`, `net10.0` |
| `AstraFlow.Mapper.Conventions` | `netstandard2.0`, `net8.0`, `net9.0`, `net10.0` |
| `AstraFlow.Diagnostics` | `netstandard2.0`, `net8.0`, `net9.0`, `net10.0` |
| `AstraFlow.Security` | `netstandard2.0`, `net8.0`, `net9.0`, `net10.0` |
| `AstraFlow.Testing` | `netstandard2.0`, `net8.0`, `net9.0`, `net10.0` |
| `AstraFlow.Assertions` | `netstandard2.0`, `net8.0`, `net9.0`, `net10.0` |
| `AstraFlow.Mapper.EntityFrameworkCore` | `net10.0` |
| `AstraFlow.AspNetCore` | `net10.0` |
| `AstraFlow.FluentValidation` | `net8.0`, `net9.0`, `net10.0` |
| `AstraFlow.OpenTelemetry` | `net8.0`, `net9.0`, `net10.0` |
| `AstraFlow.Analyzers` | Roslyn analyzer assets under `analyzers/dotnet/cs` |
| `AstraFlow.Generators` | Roslyn source generator assets under `analyzers/dotnet/cs` |

This means applications, shared libraries, contracts projects, security policy projects, and test projects on `net8.0`, `net9.0`, `net10.0`, and compatible `netstandard2.0` consumers can reference the contracts package, core packages, `AstraFlow.Mapper.Conventions`, `AstraFlow.Security`, and `AstraFlow.Testing`. The `AstraFlow.Assertions` source in the v2.4 branch targets the same four frameworks, but it is not yet a published package. EF Core projection translation validation and ASP.NET Core helpers require a `net10.0` project. FluentValidation and OpenTelemetry integration packages support `net8.0`, `net9.0`, and `net10.0`. Analyzer and generator assets are consumed by the compiler rather than referenced as runtime libraries.

### v2.1.0 generated mapping

The merged v2.1.0 source adds `AstraGenerateMappingAttribute` to `AstraFlow.Mapper` and executable output to `AstraFlow.Generators`. The generated mapping consumer sample is built for `net8.0`, `net9.0`, and `net10.0` with C# 9, the minimum language version needed for accessible partial method implementations. A GitHub Release exists, but NuGet 2.1.0 publication is unverified, so this does not change the published support table above.

A clean generated-mapping-only PackageReference consumer was published and executed as win-x64 Native AOT. This validates direct generated mapping only. It does not establish that `IMapper` assembly scanning or mediator reflection scanning is trimming/AOT-safe. The latter scan path emitted trim/AOT warnings and failed to discover a handler in a broader smoke app. Do not infer AOT support for the whole package family from the generated mapper result; see [v2.1 evidence](decisions/v2.1-draft-evidence.md).

## Compatibility Goal

The roadmap goal is broader package reach without weakening the current explicit-core behavior.

Current target policy:

| Package | Policy | Notes |
| --- | --- | --- |
| Contracts, core, conventions, security, and testing packages | Keep `netstandard2.0`, `net8.0`, `net9.0`, and `net10.0` while tests and dependencies remain healthy. | Core means mediator, mapper, conventions, diagnostics, security, testing, assertions, and meta package. |
| EF Core package | Keep target support aligned with the referenced EF Core major version. | Do not broaden EF support by silently pinning consumers to an incompatible EF Core line. |
| ASP.NET Core package | Keep target support aligned with the referenced ASP.NET Core major version. | Do not broaden ASP.NET Core support by silently pinning consumers to an incompatible framework line. |
| FluentValidation and OpenTelemetry packages | Keep `net8.0`, `net9.0`, and `net10.0` while dependencies remain healthy. | Integration dependencies stay out of core packages. |
| Analyzer package | Ship compiler analyzer assets under `analyzers/dotnet/cs`. | Do not add runtime `lib/` assets unless the package gains a separate runtime API. |

Direct .NET Framework targets such as `net462` or `net471` are candidates only after testing proves they add value beyond `netstandard2.0` consumption.

## Consumer Confidence Gates

`2.0.0` keeps the two compatibility gates introduced in `1.13.0` and the sample-build coverage introduced in `1.13.1`:

- `scripts/verify-api-compatibility.ps1` compares public XML documentation member IDs from the previous published package version to the current packed packages.
- `scripts/verify-upgrade-smoke.ps1` creates a clean consumer, builds it against the previous package version, upgrades it to the current locally packed version, and runs the same smoke flow again.
- `scripts/verify-sample-builds.ps1` builds every sample project, including host compatibility and migration cookbook samples.

These checks are intentionally conservative. `scripts/verify-public-api-baselines.ps1` is the per-target pull request gate. The NuGet comparison and upgrade smoke are release checks and require a verified prior package. The baselines cover XML documentation member IDs and do not prove binary compatibility, nullable compatibility, behavior, or undocumented member stability.

## Host Compatibility Samples

`1.13.1` includes compile-checked samples for the consumer shapes named in the roadmap:

| Consumer shape | Sample |
| --- | --- |
| Console host | `samples/ConsoleHostCompatibilitySample` |
| Worker-style host | `samples/WorkerHostCompatibilitySample` |
| ASP.NET Core host | `samples/AspNetCoreSample` |
| Class library | `samples/ClassLibraryCompatibilitySample` |
| Test project | `samples/TestProjectCompatibilitySample` |
| Shared contracts project | `samples/SharedContractsCompatibilitySample` |
| Shared client project | `samples/SharedClientCompatibilitySample` |

The integration test suite also validates the combined `AddAstraFlow(...)` registration path through a scoped Microsoft.Extensions.DependencyInjection consumer. Third-party container adapters remain candidate work until a specific container compatibility matrix is selected.

## Version Support Policy

AstraFlow supports the latest published minor version for normal package adoption, documentation, and release verification.

Patch releases should be applied within the same minor line when they are available. Minor releases should preserve source compatibility unless a breaking change is explicitly documented and moved to a major version.

The latest stable minor receives active validation. When a successor minor becomes stable, the previous minor receives security and critical-fix consideration for 90 days; after that, fixes target the latest line. This is a maintainer support window, not a promise that old packages are removed from NuGet. The exact policy is in [API governance](api-governance.md).

The maintainer reports that the top-level `AstraFlow` packages `2.2.0` and `2.3.0` are published; see the [version and upgrade guide](version-upgrade-guide.md). NuGet could not be queried from this environment, so the live publication timestamp and every satellite package's assets were not independently audited here. `2.4.0` remains unreleased. Check the exact package ID and target-framework assets before upgrading.

Security fixes should be released on the latest stable line first. Backporting to older minor lines is discretionary and depends on severity, compatibility risk, and maintainer capacity.

## Compatibility Audit Findings

The `1.2.1` audit found these items. `1.2.2` resolved the core package blockers, `1.2.3` added automated clean-install verification, `1.3.0` extended the matrix to `AstraFlow.Testing`, and `1.4.0` extends it to `AstraFlow.Contracts`.

| Area | Finding | Impact |
| --- | --- | --- |
| Project targets | Core packages now multi-target. | Done for `netstandard2.0`, `net8.0`, `net9.0`, and `net10.0`. |
| Guard APIs | Newer guard helpers were replaced in core code. | Done for supported core targets. |
| Diagnostics JSON | `System.Text.Json` is added for the `netstandard2.0` diagnostics asset. | Done. |
| EF Core package | EF validation package references EF Core `10.0.2`. | Still `net10.0`; broader EF Core support needs a separate versioning design. |
| Analyzer package | Analyzer assets ship separately from runtime libraries. | Done through `AstraFlow.Analyzers` package assets under `analyzers/dotnet/cs`. |
| Generator package | Source generator assets ship separately from runtime libraries. | Done in `1.8.4` through `AstraFlow.Generators` package assets under `analyzers/dotnet/cs`. |
| Clean install checks | `scripts/verify-package-install.ps1` installs packed packages into external consumer projects. | Done for `netstandard2.0`, `net8.0`, `net9.0`, and `net10.0` package combinations, including `AstraFlow.Testing`, `AstraFlow.Analyzers`, and `AstraFlow.Generators`. |

## Release Rules For Target Expansion

Do not add a target framework to package metadata until all of these are true:

- the package builds for that target,
- relevant tests pass for that target,
- dependencies support that target,
- a clean sample app can install and run the package,
- package contents show the expected `lib/<tfm>/` assets,
- docs list the target accurately,
- CI blocks regressions for the target.

## Consumer Guidance

The package maintainer reports `2.3.0` as the latest published AstraFlow version. This environment could not independently query NuGet, so verify the exact package ID and assets in the feed your project uses. Use the target framework matrix above to select compatible packages, then build and test the consuming solution. The v2.4 source candidate is not an installable NuGet release.

Use `AstraFlow.Mapper.EntityFrameworkCore` only from `net10.0` projects in this release.

Use `AstraFlow.AspNetCore` only from `net10.0` ASP.NET Core projects in this release.

Use `AstraFlow.FluentValidation` and `AstraFlow.OpenTelemetry` from `net8.0`, `net9.0`, or `net10.0` application projects.

Use `AstraFlow.Security` from application, shared library, tooling, or integration projects that need shared redaction and secure DTO governance policy.

Use `AstraFlow.Analyzers` as a private analyzer reference. It does not provide runtime APIs.

Use `AstraFlow.Generators` as a private generator reference. It emits source into the consuming compilation and does not provide runtime APIs.

Do not rely on roadmap candidate targets as published package support.

## EF Core Guidance

`AstraFlow.Mapper.EntityFrameworkCore` is intentionally separate from `AstraFlow.Mapper`.

Use it only in projects that need EF Core projection translation checks. The core mapper package does not require EF Core.

Future EF Core target expansion must account for EF Core major-version compatibility. It should not silently pin applications to an incompatible EF Core version.

## Verification Commands

Current release verification:

```powershell
dotnet build AstraFlow.slnx -c Release
dotnet test AstraFlow.slnx -c Release
.\scripts\pack.ps1
```

For `2.0.0`, inspect the `.nupkg` files and confirm `AstraFlow.Contracts`, the core packages, `AstraFlow.Mapper.Conventions`, `AstraFlow.Security`, and `AstraFlow.Testing` include `lib/netstandard2.0/`, `lib/net8.0/`, `lib/net9.0/`, and `lib/net10.0/`. Confirm `AstraFlow.Mapper.EntityFrameworkCore` and `AstraFlow.AspNetCore` include only `lib/net10.0/`. Confirm `AstraFlow.FluentValidation` and `AstraFlow.OpenTelemetry` include `lib/net8.0/`, `lib/net9.0/`, and `lib/net10.0/`. Confirm `AstraFlow.Analyzers` and `AstraFlow.Generators` include `analyzers/dotnet/cs/*.dll` and no runtime `lib/` assets.

Then run:

```powershell
.\scripts\verify-package-install.ps1 -Version 2.0.0
.\scripts\verify-api-compatibility.ps1 -PreviousVersion 1.13.1 -CurrentVersion 2.0.0 -AllowMissingPreviousPackages
.\scripts\verify-upgrade-smoke.ps1 -PreviousVersion 1.13.1 -CurrentVersion 2.0.0 -AllowMissingPreviousPackages
.\scripts\verify-sample-builds.ps1 -Configuration Release
```

Use `-AllowMissingPreviousPackages` for the first public package-family publish, when earlier AstraFlow package versions may not exist on NuGet. After a public baseline exists, omit the flag to make previous-version API and upgrade checks strict.
